<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('room_inventory_adjustments', function (Blueprint $t) {
            $t->id();
            $t->unsignedBigInteger('hotel_room_id');
            $t->date('date');
            $t->integer('delta'); // e.g., -2 to block two rooms; +3 to add temporary capacity
            $t->text('note')->nullable();
            $t->timestamps();

            $t->foreign('hotel_room_id')->references('hotel_room_id')->on('hotel_rooms')->onDelete('cascade');
            $t->index(['hotel_room_id', 'date']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('room_inventory_adjustments');
    }
};
