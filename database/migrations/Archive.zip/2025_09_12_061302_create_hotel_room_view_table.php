<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('hotel_room_view', function (Blueprint $t) {
            $t->unsignedBigInteger('hotel_room_id');
            $t->unsignedBigInteger('room_view_id');
            $t->primary(['hotel_room_id', 'room_view_id']);
            $t->foreign('hotel_room_id')->references('hotel_room_id')->on('hotel_rooms')->onDelete('cascade');
            $t->foreign('room_view_id')->references('room_view_id')->on('room_views')->onDelete('restrict');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('hotel_room_view');
    }
};
