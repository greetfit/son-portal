<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('hotel_amenity', function (Blueprint $t) {
            $t->unsignedBigInteger('hotel_id');
            $t->unsignedBigInteger('amenity_id');
            $t->primary(['hotel_id', 'amenity_id']);
            $t->foreign('hotel_id')->references('hotel_id')->on('hotels')->onDelete('cascade');
            $t->foreign('amenity_id')->references('amenity_id')->on('amenities')->onDelete('cascade');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('hotel_amenity');
    }
};
