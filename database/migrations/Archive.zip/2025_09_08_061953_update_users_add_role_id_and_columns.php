<?php

// database/migrations/2025_09_08_000100_add_role_id_to_users.php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration {
    public function up(): void
    {
        // Step A: add the column (nullable), no FK yet
        Schema::table('users', function (Blueprint $table) {
            if (!Schema::hasColumn('users', 'role_id')) {
                $table->unsignedBigInteger('role_id')->nullable()->after('email');
            }
        });

        // Step B: backfill role_id for every user

        // 1) get role ids
        $roleIds = DB::table('roles')->pluck('role_id', 'name'); // ['super_admin' => 1, 'manager' => 2, 'user' => 3, ...]

        // 2) if you STILL have the old string column `users.role`, map it; otherwise default to 'user'
        $hasOldRole = Schema::hasColumn('users', 'role');

        if ($hasOldRole) {
            $users = DB::table('users')->select('id', 'role')->get();
            foreach ($users as $u) {
                $rid = $roleIds[$u->role] ?? $roleIds['user'];
                DB::table('users')->where('id', $u->id)->update(['role_id' => $rid]);
            }
        }

        // 3) ensure no NULLs remain (default everyone else to 'user')
        if (isset($roleIds['user'])) {
            DB::table('users')->whereNull('role_id')->update(['role_id' => $roleIds['user']]);
        }

        // Step C: now that all users have valid role_id, add the FK (and make it NOT NULL if you want)
        Schema::table('users', function (Blueprint $table) {
            // make non-nullable if desired
            $table->unsignedBigInteger('role_id')->nullable(false)->change();

            // add FK
            $table->foreign('role_id')
                ->references('role_id')->on('roles')
                ->onDelete('restrict');
        });
    }

    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            if (Schema::hasColumn('users', 'role_id')) {
                $table->dropForeign(['role_id']);
                $table->dropColumn('role_id');
            }
        });
    }
};
