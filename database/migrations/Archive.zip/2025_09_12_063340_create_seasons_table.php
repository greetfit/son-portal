<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('seasons', function (Blueprint $t) {
            $t->id('season_id');
            $t->unsignedBigInteger('hotel_id');         // seasons can be hotel-specific
            $t->string('code', 20);                     // PEAK, SHOULDER, OFF
            $t->string('name');                         // Peak Season
            $t->date('start_date');
            $t->date('end_date');                       // inclusive
            $t->timestamps();

            $t->foreign('hotel_id')->references('hotel_id')->on('hotels')->onDelete('cascade');
            $t->unique(['hotel_id', 'code']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('seasons');
    }
};
