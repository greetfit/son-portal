<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('rate_plans', function (Blueprint $t) {
            $t->id('rate_plan_id');
            $t->unsignedBigInteger('hotel_room_id');
            $t->unsignedBigInteger('meal_plan_id');

            $t->string('code', 20)->nullable();      // e.g., DLX-BB
            $t->string('name')->nullable();          // e.g., Deluxe with Breakfast
            $t->boolean('cancellable')->default(true);
            $t->text('refund_policy')->nullable();
            $t->decimal('default_price', 12, 2);

            // New fields
            $t->text('guide_policy')->nullable();   // guide arrangements
            $t->text('child_policy')->nullable();   // structured child rules
            $t->text('notes')->nullable();          // misc notes

            $t->timestamps();

            $t->foreign('hotel_room_id')
                ->references('hotel_room_id')->on('hotel_rooms')
                ->onDelete('cascade');

            $t->foreign('meal_plan_id')
                ->references('meal_plan_id')->on('meal_plans')
                ->onDelete('restrict');

            $t->unique(['hotel_room_id', 'meal_plan_id']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('rate_plans');
    }
};
