<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('season_prices', function (Blueprint $t) {
            $t->id();
            $t->unsignedBigInteger('rate_plan_id');
            $t->unsignedBigInteger('season_id');
            $t->decimal('price', 12, 2);                // season price per night
            $t->timestamps();

            $t->foreign('rate_plan_id')->references('rate_plan_id')->on('rate_plans')->onDelete('cascade');
            $t->foreign('season_id')->references('season_id')->on('seasons')->onDelete('cascade');
            $t->unique(['rate_plan_id', 'season_id']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('season_prices');
    }
};
