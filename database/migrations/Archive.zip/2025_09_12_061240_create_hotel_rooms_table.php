<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('hotel_rooms', function (Blueprint $t) {
            $t->id('id');
            $t->unsignedBigInteger('hotel_id');
            $t->unsignedBigInteger('room_type_id');      // e.g., DLX
            $t->unsignedBigInteger('room_category_id');  // Standard/Deluxe/Premium
            $t->unsignedBigInteger('occupancy_type_id'); // Single/Double/Triple
            $t->unsignedInteger('total_rooms')->default(1);
            $t->unsignedTinyInteger('base_occupancy')->default(2);
            $t->unsignedTinyInteger('max_occupancy')->default(3);
            $t->timestamps();

            $t->foreign('hotel_id')->references('hotel_id')->on('hotels')->onDelete('cascade');
            $t->foreign('room_type_id')->references('room_type_id')->on('room_types')->onDelete('restrict');
            $t->foreign('room_category_id')->references('room_category_id')->on('room_categories')->onDelete('restrict');
            $t->foreign('occupancy_type_id')->references('occupancy_type_id')->on('occupancy_types')->onDelete('restrict');

            // Prevent duplicate definitions
            $t->unique(['hotel_id', 'room_type_id', 'room_category_id', 'occupancy_type_id'], 'uniq_hotel_room_combo');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('hotel_rooms');
    }
};
