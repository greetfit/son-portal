<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('promotions', function (Blueprint $t) {
            $t->id('promotion_id');
            $t->unsignedBigInteger('hotel_id');
            $t->string('code', 30)->unique();            // e.g., WINTER25
            $t->string('name');
            $t->enum('discount_type', ['percent', 'flat']);
            $t->decimal('discount_value', 12, 2);        // 25.00 (%) or 2500.00 (flat currency)
            $t->date('book_from')->nullable();           // booking window
            $t->date('book_to')->nullable();
            $t->date('stay_from')->nullable();           // stay/travel window
            $t->date('stay_to')->nullable();
            $t->unsignedTinyInteger('min_nights')->default(1);
            $t->unsignedTinyInteger('max_nights')->nullable();
            $t->boolean('stackable')->default(false);    // can combine with other promos?
            $t->json('blackout_dates')->nullable();      // ["2025-12-31","2026-01-01"]
            $t->json('conditions')->nullable();          // flexible JSON (see below)
            $t->boolean('active')->default(true);
            $t->timestamps();

            $t->foreign('hotel_id')->references('hotel_id')->on('hotels')->onDelete('cascade');
        });

        // link promotions to the specific rate plans they apply to
        Schema::create('promotion_rate_plan', function (Blueprint $t) {
            $t->unsignedBigInteger('promotion_id');
            $t->unsignedBigInteger('rate_plan_id');
            $t->primary(['promotion_id', 'rate_plan_id']);

            $t->foreign('promotion_id')->references('promotion_id')->on('promotions')->onDelete('cascade');
            $t->foreign('rate_plan_id')->references('rate_plan_id')->on('rate_plans')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('promotions');
    }
};
