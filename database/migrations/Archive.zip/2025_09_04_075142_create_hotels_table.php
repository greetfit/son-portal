<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('hotels', function (Blueprint $t) {
            $t->id('id'); // BIGINT UNSIGNED
            $t->string('name', 150);
            $t->text('description')->nullable();
            $t->string('address', 255)->nullable();
            // IMPORTANT: cities.id is UNSIGNED INT in your DB => match type here
            $t->unsignedInteger('city_id')->nullable();
            $t->string('phone', 50)->nullable();
            $t->string('email', 100)->nullable();
            $t->string('website', 150)->nullable();
            $t->unsignedTinyInteger('star_rating')->nullable(); // 3,4,5
            $t->string('featured_image',255)->nullable(); // featured image URL or path
            $t->timestamps();
            $t->foreign('city_id')->references('id')->on('cities')->onDelete('set null');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('hotels');
    }
};
