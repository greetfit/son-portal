<template>
  <FileUpload title="Add Agent Photo" />
</template>
<script setup lang="ts">
import FileUpload from "@/components/FileUpload.vue";
</script>