<template>
<b-card no-body>
          <b-card-header>
            <b-card-title>Top Agents</b-card-title>
          </b-card-header>
          <b-card-body>
            <div class="bg-primary position-relative rounded p-2 overflow-hidden z-1 text-center">
              <img :src="agent1" alt="" class="img-fluid rounded">
              <div
                class="d-flex align-items-center justify-content-between bg-light bg-opacity-25 p-2 mt-2 rounded text-start">
                <div>
                  <a href="#!" class="text-white fw-medium fs-16">Lahomes Group , Pvt Ltd</a>
                  <p class="mb-0 text-white-50">Markova , USA</p>
                  <div class="d-flex flex-wrap gap-2 align-items-center mt-1">
                    <ul class="d-flex text-warning m-0 fs-18  list-unstyled">
                      <li>
                        <i class='ri-star-fill'></i>
                      </li>
                      <li>
                        <i class='ri-star-fill'></i>
                      </li>
                      <li>
                        <i class='ri-star-fill'></i>
                      </li>
                      <li>
                        <i class='ri-star-fill'></i>
                      </li>
                      <li>
                        <i class='ri-star-half-line'></i>
                      </li>
                    </ul>
                    <p class="mb-0 text-white">4.5 / 5 Rating</p>
                  </div>
                </div>
                <div>
                  <a href="#!">
                    <div class="avatar-sm flex-shrink-0">
                      <span class="avatar-title bg-primary text-white fs-4 rounded-circle">
                        <i class='ri-arrow-right-line'></i>
                      </span>
                    </div>
                  </a>
                </div>
              </div>
            </div>
          </b-card-body>
        </b-card>
</template>
<script setup lang="ts">
import agent1 from "@/assets/images/agent-1.png"
</script>