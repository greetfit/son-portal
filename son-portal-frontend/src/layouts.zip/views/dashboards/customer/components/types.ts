export type CustomerType = {
  img: string;
  name: string;
  email: string;
  amount: number;
};