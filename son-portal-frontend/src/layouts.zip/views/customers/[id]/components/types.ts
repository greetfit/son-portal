export type TransactionsType = {
  id: string;
  date: string;
  category: string;
  location: string;
  amount: number;
  agentName: string;
};