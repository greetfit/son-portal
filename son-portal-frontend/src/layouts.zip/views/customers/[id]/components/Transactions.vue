<template>
<b-card no-body>
          <b-card-header>
            <b-card-title>Transactions </b-card-title>
          </b-card-header>
          <b-card-body>
            <div class="p-3 bg-primary bg-gradient rounded-4 border border-light border-2 shadow-sm">
              <div class="d-flex align-items-center">
                <img :src="chip" alt="" class="avatar">
                <div class="ms-auto">
                  <img :src="mastercard" alt="" class="avatar">
                </div>
              </div>
              <div class="mt-5">

                <h4 class="text-white d-flex gap-2"><span class="text-white-50">XXXX</span> <span
                    class="text-white-50">XXXX</span> <span class="text-white-50">XXXX</span> 3467</h4>
              </div>
              <div class="d-flex align-items-center justify-content-between mt-4">
                <div>
                  <p class="text-white-50 mb-2">Holder Name</p>
                  <h4 class="mb-0 text-white">Ray C. Nichols</h4>
                </div>
                <div>
                  <p class="text-white-50 mb-2">Valid</p>
                  <h4 class="mb-0 text-white">05/26</h4>
                </div>
                <img :src="contactless" alt="" class="img-fluid">
              </div>
            </div>
            <div class="mt-4">
              <div class="d-flex align-items-center gap-3 border-bottom pb-3">
                <div class="avatar bg-primary bg-opacity-10 rounded">
                  <div class="avatar-title">
                    <Icon icon="solar:square-transfer-horizontal-bold" class="fs-28 text-primary" />
                  </div>
                </div>
                <div>
                  <p class="mb-1 text-dark fw-medium fs-15">Michael A. Miner</p>
                  <p class="text-muted mb-0">michaelminer@dayrep.com</p>
                </div>
                <div class="ms-auto">
                  <p class="mb-1 fs-16 text-dark fw-medium">{{ currency }}13,987 <span><i
                        class="ri-checkbox-circle-line text-success ms-1"></i></span></p>
                  <p class="mb-0 fs-13">TXN-341220</p>
                </div>
              </div>
              <div class="d-flex align-items-center gap-3 pt-3 rounded">
                <div class="avatar bg-primary bg-opacity-10 rounded">
                  <div class="avatar-title">
                    <Icon icon="solar:square-transfer-horizontal-bold" class="fs-28 text-primary" />
                  </div>
                </div>
                <div>
                  <p class="mb-1 text-dark fw-medium fs-15">Theresa T. Brose</p>
                  <p class="text-muted mb-0">theresbrosea@dayrep.com</p>
                </div>
                <div class="ms-auto">
                  <p class="mb-1 fs-16 text-dark fw-medium">{{ currency }}2,710 <span><i
                        class="ri-checkbox-circle-line text-success ms-1"></i></span></p>
                  <p class="mb-0 fs-13">TXN-836451</p>
                </div>
              </div>
              <div class="mt-4">
                <a href="#!" class="link-primary fw-medium">View More</a>
              </div>
            </div>
          </b-card-body>
        </b-card>
</template>
<script setup lang="ts">
import { currency } from "@/helpers/constants";
import { Icon } from "@iconify/vue";

import chip from "@/assets/images/chip.png"
import mastercard from "@/assets/images/card/mastercard.svg"
import contactless from "@/assets/images/contactless-payment.png"
</script>