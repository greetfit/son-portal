<template>
  <VerticalLayout>
    <PageTitle title="Solar Icons" subtitle="Icons"/>

    <div class="d-flex flex-wrap align-items-center justify-content-between gap-3 mb-3">
      <b-card no-body class="icon-box">
        <b-card-body class="d-flex flex-column align-items-center justify-content-center">
          <Icon icon="solar:leaf-bold-duotone" class="fs-2 text-primary" />
          <h5 class="mt-2 mb-0">Leaf</h5>
        </b-card-body>
      </b-card>

      <b-card no-body class="icon-box">
        <b-card-body class="d-flex flex-column align-items-center justify-content-center">
          <Icon icon="solar:airbuds-bold-duotone" class="fs-2" />
          <h5 class="mt-2 mb-0">Airbuds</h5>
        </b-card-body>
      </b-card>

      <b-card no-body class="icon-box">
        <b-card-body class="d-flex flex-column align-items-center justify-content-center">
          <Icon icon="solar:adhesive-plaster-bold-duotone" class="fs-2" />
          <h5 class="mt-2 mb-0">Plaster</h5>
        </b-card-body>
      </b-card>

      <b-card no-body class="icon-box">
        <b-card-body class="d-flex flex-column align-items-center justify-content-center">
          <Icon icon="solar:bicycling-round-bold-duotone" class="fs-2" />
          <h5 class="mt-2 mb-0">Bicycling</h5>
        </b-card-body>
      </b-card>

      <b-card no-body class="icon-box">
        <b-card-body class="d-flex flex-column align-items-center justify-content-center">
          <Icon icon="solar:bookmark-circle-bold-duotone" class="fs-2 text-success" />
          <h5 class="mt-2 mb-0">Bookmark</h5>
        </b-card-body>
      </b-card>

      <b-card no-body class="icon-box">
        <b-card-body class="d-flex flex-column align-items-center justify-content-center">
          <Icon icon="solar:crown-bold-duotone" class="fs-2" />
          <h5 class="mt-2 mb-0">Crown</h5>
        </b-card-body>
      </b-card>

      <b-card no-body class="icon-box">
        <b-card-body class="d-flex flex-column align-items-center justify-content-center">
          <Icon icon="solar:asteroid-broken" class="fs-2" />
          <h5 class="mt-2 mb-0">Asteroid</h5>
        </b-card-body>
      </b-card>

      <b-card no-body class="icon-box">
        <b-card-body class="d-flex flex-column align-items-center justify-content-center">
          <Icon icon="solar:bar-chair-broken" class="fs-2" />
          <h5 class="mt-2 mb-0">Bar Chair</h5>
        </b-card-body>
      </b-card>

      <b-card no-body class="icon-box">
        <b-card-body class="d-flex flex-column align-items-center justify-content-center">
          <Icon icon="solar:black-hole-line-duotone" class="fs-2 text-info" />
          <h5 class="mt-2 mb-0">Hole</h5>
        </b-card-body>
      </b-card>

      <b-card no-body class="icon-box">
        <b-card-body class="d-flex flex-column align-items-center justify-content-center">
          <Icon icon="solar:bookmark-circle-broken" class="fs-2" />
          <h5 class="mt-2 mb-0">Bookmark</h5>
        </b-card-body>
      </b-card>

      <b-card no-body class="icon-box">
        <b-card-body class="d-flex flex-column align-items-center justify-content-center">
          <Icon icon="solar:cart-4-broken" class="fs-2" />
          <h5 class="mt-2 mb-0">Cart</h5>
        </b-card-body>
      </b-card>

      <b-card no-body class="icon-box">
        <b-card-body class="d-flex flex-column align-items-center justify-content-center">
          <Icon icon="solar:cart-large-4-bold-duotone" class="fs-2" />
          <h5 class="mt-2 mb-0">Cart Large</h5>
        </b-card-body>
      </b-card>

      <b-card no-body class="icon-box">
        <b-card-body class="d-flex flex-column align-items-center justify-content-center">
          <Icon icon="solar:chat-round-unread-bold-duotone" class="fs-2 text-dark" />
          <h5 class="mt-2 mb-0">Chat</h5>
        </b-card-body>
      </b-card>

      <b-card no-body class="icon-box">
        <b-card-body class="d-flex flex-column align-items-center justify-content-center">
          <Icon icon="solar:closet-2-bold-duotone" class="fs-2" />
          <h5 class="mt-2 mb-0">Closet</h5>
        </b-card-body>
      </b-card>

      <b-card no-body class="icon-box">
        <b-card-body class="d-flex flex-column align-items-center justify-content-center">
          <Icon icon="solar:cloud-snowfall-minimalistic-line-duotone" class="fs-2" />
          <h5 class="mt-2 mb-0">Cloud</h5>
        </b-card-body>
      </b-card>

      <b-card no-body class="icon-box">
        <b-card-body class="d-flex flex-column align-items-center justify-content-center">
          <Icon icon="solar:command-bold-duotone" class="fs-2" />
          <h5 class="mt-2 mb-0">Command</h5>
        </b-card-body>
      </b-card>

      <b-card no-body class="icon-box">
        <b-card-body class="d-flex flex-column align-items-center justify-content-center">
          <Icon icon="solar:compass-big-bold-duotone" class="fs-2 text-warning" />
          <h5 class="mt-2 mb-0">Compass</h5>
        </b-card-body>
      </b-card>

      <b-card no-body class="icon-box">
        <b-card-body class="d-flex flex-column align-items-center justify-content-center">
          <Icon icon="solar:confetti-minimalistic-line-duotone" class="fs-2" />
          <h5 class="mt-2 mb-0">Confetti</h5>
        </b-card-body>
      </b-card>

      <b-card no-body class="icon-box">
        <b-card-body class="d-flex flex-column align-items-center justify-content-center">
          <Icon icon="solar:corkscrew-bold-duotone" class="fs-2" />
          <h5 class="mt-2 mb-0">Corkscrew</h5>
        </b-card-body>
      </b-card>

      <b-card no-body class="icon-box">
        <b-card-body class="d-flex flex-column align-items-center justify-content-center">
          <Icon icon="solar:cup-hot-line-duotone" class="fs-2" />
          <h5 class="mt-2 mb-0">Cup</h5>
        </b-card-body>
      </b-card>

      <b-card no-body class="icon-box">
        <b-card-body class="d-flex flex-column align-items-center justify-content-center">
          <Icon icon="solar:dollar-bold-duotone" class="fs-2 text-danger" />
          <h5 class="mt-2 mb-0">Dollar</h5>
        </b-card-body>
      </b-card>

      <b-card no-body class="icon-box">
        <b-card-body class="d-flex flex-column align-items-center justify-content-center">
          <Icon icon="solar:dumbbell-large-bold-duotone" class="fs-2" />
          <h5 class="mt-2 mb-0">Dumbbell</h5>
        </b-card-body>
      </b-card>

      <b-card no-body class="icon-box">
        <b-card-body class="d-flex flex-column align-items-center justify-content-center">
          <Icon icon="solar:electric-refueling-bold-duotone" class="fs-2" />
          <h5 class="mt-2 mb-0">Refueling</h5>
        </b-card-body>
      </b-card>

      <b-card no-body class="icon-box">
        <b-card-body class="d-flex flex-column align-items-center justify-content-center">
          <Icon icon="solar:earth-line-duotone" class="fs-2" />
          <h5 class="mt-2 mb-0">Earth</h5>
        </b-card-body>
      </b-card>

      <b-card no-body class="icon-box">
        <b-card-body class="d-flex flex-column align-items-center justify-content-center">
          <Icon icon="solar:figma-bold-duotone" class="fs-2" />
          <h5 class="mt-2 mb-0">Figma</h5>
        </b-card-body>
      </b-card>

      <b-card no-body class="icon-box">
        <b-card-body class="d-flex flex-column align-items-center justify-content-center">
          <Icon icon="solar:flame-bold-duotone" class="fs-2" />
          <h5 class="mt-2 mb-0">Flame</h5>
        </b-card-body>
      </b-card>

      <b-card no-body class="icon-box">
        <b-card-body class="d-flex flex-column align-items-center justify-content-center">
          <Icon icon="solar:floor-lamp-line-duotone" class="fs-2" />
          <h5 class="mt-2 mb-0">Lamp</h5>
        </b-card-body>
      </b-card>

      <b-card no-body class="icon-box">
        <b-card-body class="d-flex flex-column align-items-center justify-content-center">
          <Icon icon="solar:gallery-round-bold-duotone" class="fs-2" />
          <h5 class="mt-2 mb-0">Gallery</h5>
        </b-card-body>
      </b-card>

      <b-card no-body class="icon-box">
        <b-card-body class="d-flex flex-column align-items-center justify-content-center">
          <Icon icon="solar:ghost-line-duotone" class="fs-2" />
          <h5 class="mt-2 mb-0">Ghost</h5>
        </b-card-body>
      </b-card>

      <b-card no-body class="icon-box">
        <b-card-body class="d-flex flex-column align-items-center justify-content-center">
          <Icon icon="solar:kick-scooter-bold-duotone" class="fs-2" />
          <h5 class="mt-2 mb-0">Scooter</h5>
        </b-card-body>
      </b-card>
    </div>

    <div class="my-4 text-center">
      <a href="https://icon-sets.iconify.design/solar/" target="_blank" class="btn btn-primary">View All Icons</a>
    </div>
  </VerticalLayout>
</template>

<script setup lang="ts">
import VerticalLayout from "@/layouts/VerticalLayout.vue";
import { Icon } from '@iconify/vue';
import PageTitle from "@/components/PageTitle.vue";
</script>
