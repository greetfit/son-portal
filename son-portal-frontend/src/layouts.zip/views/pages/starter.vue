<template>
  <VerticalLayout>
    <PageTitle title="Welcome" subtitle="Pages"/>
  </VerticalLayout>
</template>

<script setup lang="ts">
import VerticalLayout from '@/layouts/VerticalLayout.vue'
import PageTitle from "@/components/PageTitle.vue";
</script>
