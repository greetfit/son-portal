declare module 'vue3-clipboard'
declare module 'sweetalert2/dist/sweetalert2.js'
declare module 'rater-js/index'